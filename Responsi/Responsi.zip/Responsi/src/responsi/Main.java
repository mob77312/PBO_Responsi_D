
package responsi;

/**
 *
 * @author Muhammad Akli adnan
 */
public class Main {

    public static void main(String[] args) {
        Home home = new Home();
    }
    
}
