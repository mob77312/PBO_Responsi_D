/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package responsi;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import static responsi.Model.JDBC_DRIVER;
public class ModelPegawai {
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/responsi_pbo";   
    static final String USER = "root";
    static final String PASS = "";
    
    Connection koneksi;
    Statement statement;   
 public ModelPegawai(){
        try{
            Class.forName(JDBC_DRIVER);
            koneksi = (Connection) DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Koneksi Berhasil");
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
            System.out.println("Koneksi Gagal");
        }
    }
    

    
    public String[][] read() {      
        try{
            int jmldata = 0;           
            String data[][] = new String[getBanyakData()][10];   
            String query = "Select * from `data_pegawai`";
            ResultSet resultset = statement.executeQuery(query);
            while(resultset.next()) {
                data[jmldata][0] = resultset.getString("id");
                data[jmldata][1] = resultset.getString("nama");
                data[jmldata][2] = resultset.getString("posisi");
                data[jmldata][3] = resultset.getString("gaji_pokok");
                data[jmldata][4] = resultset.getString("jam_lembur");
                data[jmldata][5] = resultset.getString("tunjangan");
                data[jmldata][6] = resultset.getString("total");
                jmldata = jmldata+1;
            }
            return data;
            
        } catch(SQLException e) {
            System.out.println(e.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    
        public int getBanyakData() {
            int jmldata = 0;
            try{
                statement = (Statement)koneksi.createStatement();
                String query = "Select * from `data_pegawai`";
                ResultSet resultset = statement.executeQuery(query);
                while(resultset.next()) {
                    jmldata++;
                }
                return jmldata;
            } catch(SQLException e){
                System.out.println(e.getMessage());
                System.out.println("SQL Error");
                return 0;
            }
        }    
}
