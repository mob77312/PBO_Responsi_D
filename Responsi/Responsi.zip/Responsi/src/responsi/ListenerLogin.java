
package responsi;

public interface ListenerLogin {
    public void onChange(ModelLogin modelLogin);
}
