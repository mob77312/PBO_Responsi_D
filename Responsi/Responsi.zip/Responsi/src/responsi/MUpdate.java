
package responsi;

public class MUpdate {
    Update update = new Update();
    UpdateModel model = new UpdateModel();
    UpdateController controller = new UpdateController(model, update);
}
