/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package responsi;

/**
 *
 * @author ACER
 */
public class MReadPegawai {
        //untuk menghubungkan 3 kelas view model dan controller
    ReadPegawai read = new ReadPegawai();
    ModelPegawai model = new ModelPegawai();
    PegawaiController controller = new PegawaiController(model, read);
}
